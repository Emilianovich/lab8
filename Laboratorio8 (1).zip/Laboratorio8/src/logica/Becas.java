package logica;
import java.util.ArrayList;

public class Becas {
	private static final int MAX_ESTUDIANTES = 100;
    public static ArrayList<Estudiantes> estudiantes;

    public Becas() {
        estudiantes = new ArrayList<>();
    }

    public void agregarEstudiante(Estudiantes estudiante) {
        if (estudiantes.size() < MAX_ESTUDIANTES) {
            estudiantes.add(estudiante);
        } else {
            System.out.println("No se puede agregar más estudiantes. Límite alcanzado.");
        }
    }

    public ArrayList<String> obtenerEstudiantesBecados() {
        ArrayList<String> estudiantesBecados = new ArrayList<>();

        for (Estudiantes estudiante : estudiantes) {
            if (estudiante.getIndiceAcademico() >= 2.0) {
                estudiantesBecados.add(estudiante.getNombre());
            }
        }

        return estudiantesBecados;
    }
    
    public static Estudiantes buscarCed(String cedula) {
		for (Estudiantes estudiante : estudiantes) {
			if (estudiante.getCedula().equals(cedula)) {
				return estudiante;
			}
		}
		return null;
	}
    
    public static Estudiantes buscarSexo(String sexo, String carrera) {
        for (Estudiantes estudiante : estudiantes) {
            if (estudiante.getIndiceAcademico() >= 2.0 && estudiante.getSexo().equals(sexo) && estudiante.getCarrera().equals(carrera)) {
                return estudiante;
            }
        }
        return null;
    }
}

