/**
 * 
 */
/**
 * 
 */
module Laboratorio8 {
	requires java.desktop;
}