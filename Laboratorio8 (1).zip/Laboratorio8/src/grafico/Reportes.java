package grafico;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import logica.Becas;
import logica.Estudiantes;

import javax.swing.JLabel;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class Reportes extends JFrame {
	private JTextArea textAreaBecados;
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblBuscCed;
	private JTextField textBusqCed;
	private JButton btnBusqCed;
	private JLabel lblBusqSexo;
	private JComboBox comboBoxBusqSexo;
	private JLabel lblBusqCarrera;
	private JComboBox comboBoxBusqCarrera;
	private JLabel lblBusqSexCarrera;
	private JButton btnbusqSexCarrera;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reportes frame = new Reportes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Reportes() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 666, 483);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Reportes");
		lblNewLabel.setBounds(238, 10, 149, 46);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 32));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Estudiantes Becados:");
		lblNewLabel_1.setBounds(52, 106, 221, 35);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		contentPane.add(lblNewLabel_1);
		
		textAreaBecados = new JTextArea();
		textAreaBecados.setEditable(false);
		textAreaBecados.setBounds(52, 151, 184, 220);
		contentPane.add(textAreaBecados);
		
		lblBuscCed = new JLabel("Búsqueda por cédula:");
		lblBuscCed.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBuscCed.setHorizontalAlignment(SwingConstants.CENTER);
		lblBuscCed.setBounds(319, 128, 149, 27);
		contentPane.add(lblBuscCed);
		
		textBusqCed = new JTextField();
		textBusqCed.setBounds(467, 133, 97, 20);
		contentPane.add(textBusqCed);
		textBusqCed.setColumns(10);
		
		btnBusqCed = new JButton("Buscar");
		btnBusqCed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cedula = textBusqCed.getText();
				Estudiantes estudiante = Becas.buscarCed(cedula);
					if (estudiante != null) {
					JOptionPane.showMessageDialog(contentPane, "Estudiante encontrado:\n" + estudiante.getNombre(), "Resultado de la búsqueda", JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(contentPane, "No se encontró un estudiante con la cédula proporcionada.", "Resultado de la búsqueda", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnBusqCed.setBounds(435, 168, 89, 23);
		contentPane.add(btnBusqCed);
		
		lblBusqSexo = new JLabel("Sexo:");
		lblBusqSexo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBusqSexo.setHorizontalAlignment(SwingConstants.CENTER);
		lblBusqSexo.setBounds(272, 227, 46, 27);
		contentPane.add(lblBusqSexo);
		
		comboBoxBusqSexo = new JComboBox();
		comboBoxBusqSexo.setModel(new DefaultComboBoxModel(new String[] {"Femenino", "Masculino"}));
		comboBoxBusqSexo.setBounds(319, 231, 111, 22);
		comboBoxBusqSexo.setSelectedIndex(-1);
		contentPane.add(comboBoxBusqSexo);
		
		lblBusqCarrera = new JLabel("Carrera:");
		lblBusqCarrera.setHorizontalAlignment(SwingConstants.CENTER);
		lblBusqCarrera.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBusqCarrera.setBounds(254, 265, 64, 27);
		contentPane.add(lblBusqCarrera);
		
		comboBoxBusqCarrera = new JComboBox();
		comboBoxBusqCarrera.setModel(new DefaultComboBoxModel(new String[] {"Ingeniería Civil", "Ingeniería Eléctrica", "Ingeniería Industrial", "Ingeniería en Sistemas", "Ingeniería Mecánica", "Ingeniería Marítima"}));
		comboBoxBusqCarrera.setBounds(319, 269, 111, 22);
		comboBoxBusqCarrera.setSelectedIndex(-1);
		contentPane.add(comboBoxBusqCarrera);
		
		lblBusqSexCarrera = new JLabel("Búsqueda por sexo y carrera:");
		lblBusqSexCarrera.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBusqSexCarrera.setBounds(272, 202, 203, 20);
		contentPane.add(lblBusqSexCarrera);
		
		btnbusqSexCarrera = new JButton("Buscar");
		btnbusqSexCarrera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String estudSex = (String) comboBoxBusqSexo.getSelectedItem(); 
		        String estudCarrera = (String) comboBoxBusqCarrera.getSelectedItem(); 
		        Estudiantes estudiante = Becas.buscarSexo(estudSex, estudCarrera);
		        if (estudiante != null) {
		            JOptionPane.showMessageDialog(contentPane, "Estudiante encontrado:\n" + estudiante.getNombre(), "Resultado de la búsqueda", JOptionPane.INFORMATION_MESSAGE);
		        } else {
		            JOptionPane.showMessageDialog(contentPane, "No se encontró un estudiante becado con la información proporcionada.", "Resultado de la búsqueda", JOptionPane.ERROR_MESSAGE);
		        }
			}
		});
		btnbusqSexCarrera.setBounds(319, 302, 89, 23);
		contentPane.add(btnbusqSexCarrera);

		
	}
	void mostrarBecados(Becas becas) {
        System.out.println("Estudiantes becados obtenidos: " + becas.obtenerEstudiantesBecados().size());

        StringBuilder sb = new StringBuilder();

        for (String nombre : becas.obtenerEstudiantesBecados()) {
            sb.append(nombre).append("\n");
        }

        textAreaBecados.setText(sb.toString());
    }
}
